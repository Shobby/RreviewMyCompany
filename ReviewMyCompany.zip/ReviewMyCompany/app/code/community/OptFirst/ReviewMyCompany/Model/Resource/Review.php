<?php

class OptFirst_ReviewMyCompany_Model_Resource_Review extends Mage_Core_Model_Resource_Db_Abstract
{
     public function _construct()
     {
         $this->_init('optfirst_reviewmycompany/review', 'id_optfirst_reviewmycompany');
     }
}
?>